﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarBuyingSystem
{
    public partial class AddClientForm : Form
    {

        Controller controller;
        Clients parentForm;
        public AddClientForm(Controller controller, Clients clients)
        {
            InitializeComponent();
            this.controller = controller;
            this.parentForm = clients;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            String clientName = clientNameFiled.Text;
            String clientPhone = clientPhoneField.Text;
            String clientEmail = clientEmailField.Text;
            int costFrom = int.Parse(costFromFilterField.Text);
            int costTo = int.Parse(costToFilterField.Text);

            Client client = new Client(clientName,clientEmail, clientPhone, ClientStatus.NEW, costFrom, costTo);

            controller.addClient(client);
            parentForm.LoadData();
            this.Close();

        }
    }
}
