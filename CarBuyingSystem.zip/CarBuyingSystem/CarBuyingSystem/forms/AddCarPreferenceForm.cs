﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarBuyingSystem
{
    public partial class AddCarPreferenceForm : Form
    {

        private Client client;
        private ClientPageForm parentForm;
        private Button btnSubmit;
        public AddCarPreferenceForm(Client client, ClientPageForm parentForm)
        {
            InitializeComponent();
            this.client = client;
            this.parentForm = parentForm;
            LoadData();
        }
        private void LoadData()
        {
            List<string> carVendors = new List<string>()
            {
                "Toyota", "BMW", "FORD", "AC", "Alphine", "Audi","Acura", "Aro", "Austin", "Alfa Romeo", "Asia", "Alpina","Aston Martin"
                ,"BAW","Brilliance","BYD","Beijing","Bristol","Богдан","Bentley","Bugatti","Buick",
                "Vector","Vortex","Wuling","Venturi","Wartburg","ВАЗ (Lada)","Volkswagen","Westfield",
                "Volvo","Wiesmann","Geely","ГАЗ","Geo","GMC","Great Wall","Dacia","Daimler","Dodge","Jiangling","Dadi","Dallas","Dong Feng","Jiangnan","Daewoo","Derways","Doninvest","Daihatsu","De Tomaso","Jeep","Eagle","Zastava","ZX","ЗАЗ","ЗИЛ","Infiniti","Isdera","ИЖ","Innocenti","Isuzu","Invicta","IVECO","Iran Khodro","Xin Kai","Cadillac","Citroen","Koenigsegg","Callaway","Cizeta","Qvale","Carbodies","Coggiola","КАМАЗ","Caterham","Kia","Lamborghini","Lexus","LTI","Lancia","Lifan","Luxgen","Land Rover","Lincoln","ЛуАЗ","Landwind","Lotus","Mahindra","Maruti","McLaren","Metrocab","Mitsubishi","Москвич","Marcos","Maserati","Mega","MG","Mitsuoka","Marlin","Maybach","Mercedes-Benz","Minelli","Monte Carlo","Marussia","Mazda","Mercury","Mini","Morgan","Nissan","Noble","Oldsmobile","Opel","Pagani","Peugeot","Premier","Panoz","Plymouth","Proton","Paykan","Pontiac","Puma","Perodua","Porsche","Reliant","Rover","Renault","Ravon","Rolls-Royce","Ronart","Toyota","BMW", "FORD", "AC", "Alphine", "Audi","Acura", "Aro", "Austin", "Alfa Romeo", "Asia", "Alpina","Aston Martin","BAW","Brilliance","BYD","Beijing","Bristol","Богдан","Bentley","Bugatti","Buick","Vector","Vortex","Wuling","Venturi","Wartburg","ВАЗ (Lada)","Volkswagen","Westfield","Volvo","Wiesmann","Geely","ГАЗ","Geo","GMC","Great Wall","Dacia","Daimler","Dodge","Jiangling","Dadi","Dallas","Dong Feng","Jiangnan","Daewoo","Derways","Doninvest","Daihatsu","De Tomaso","Jeep","Eagle","Zastava","ZX","ЗАЗ","ЗИЛ","Infiniti","Isdera","ИЖ","Innocenti","Isuzu","Invicta","IVECO","Iran Khodro","Xin Kai","Cadillac","Citroen","Koenigsegg","Callaway","Cizeta","Qvale","Carbodies","Coggiola","КАМАЗ","Caterham","Kia","Lamborghini","Lexus","LTI","Lancia","Lifan","Luxgen","Land Rover","Lincoln","ЛуАЗ","Landwind","Lotus","Mahindra","Maruti","McLaren","Metrocab","Mitsubishi","Москвич","Marcos","Maserati","Mega","MG","Mitsuoka","Marlin","Maybach","Mercedes-Benz","Minelli","Monte Carlo","Marussia","Mazda","Mercury","Mini","Morgan","Москвич","Nissan","Noble","Oldsmobile","Opel","Pagani","Peugeot","Premier","Panoz","Plymouth","Proton","Paykan","Pontiac","Puma","Perodua","Porsche","Reliant","Rover","Renault","Ravon","Rolls-Royce","Ronart","Saab","Scion","Smart","Subaru","Saleen","SEAT","Soueast","Suzuki","Samsung","Skoda","Spectre","СеАЗ","Saturn","SMA","SsangYong","Talbot","Tofas","ТагАЗ","Tata","Toyota","Tatra","Trabant","Tianma","TVR","УАЗ","FAW","FSO","Ferrari","Fuqi","Fiat","Ford","Hafei","Honda","Haval","Haima","HuangHai","Hindustan","Hummer","Holden","Hyundai","Chana","Chevrolet","ChangFeng","Chrysler","Changhe","Chery","Shifeng","ShuangHuan","JAC","Jaguar"


            };

            comboBox1.DataSource = carVendors;

       

            List<string> colors = new List<string>()
            {
                "Black", "White" , "Red" , "Yellow" , "Orange" , "Green" , "Blue" , "Purpel" , "Pink" , "Brown" , "Gray"
            };

            comboBox2.DataSource = colors;

         

        }


        private void InitializeComponent()
        {
            this.btnSubmit = new System.Windows.Forms.Button();

            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();

            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();

            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
          
            this.cars = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            
           
           
          

            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmit.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSubmit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSubmit.Location = new System.Drawing.Point(12, 231);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(360, 60);
            this.btnSubmit.TabIndex = 12;
            this.btnSubmit.Text = "SAVE";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(12, 106);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(116, 60);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Vendor";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(8, 24);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 24);
            this.comboBox1.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.Location = new System.Drawing.Point(134, 106);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(116, 60);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Model";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(6, 25);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.Location = new System.Drawing.Point(256, 106);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(116, 60);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Year";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2.Location = new System.Drawing.Point(6, 25);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBox4);
            this.groupBox5.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox5.Location = new System.Drawing.Point(134, 165);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(116, 60);
            this.groupBox5.TabIndex = 18;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Transmission";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox4.Location = new System.Drawing.Point(6, 25);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.comboBox2);
            this.groupBox6.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox6.Location = new System.Drawing.Point(12, 165);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(116, 60);
            this.groupBox6.TabIndex = 17;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Color";
            // 
            // cars
            // 
            this.cars.AutoSize = true;
            this.cars.BackColor = System.Drawing.Color.DodgerBlue;
            this.cars.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cars.ForeColor = System.Drawing.Color.Linen;
            this.cars.Location = new System.Drawing.Point(87, 34);
            this.cars.Name = "cars";
            this.cars.Size = new System.Drawing.Size(220, 34);
            this.cars.TabIndex = 2;
            this.cars.Text = "Car Preference";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.cars);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(385, 100);
            this.panel1.TabIndex = 26;

            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox3);
            this.groupBox4.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox4.Location = new System.Drawing.Point(256, 165);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(116, 60);
            this.groupBox4.TabIndex = 27;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Engine";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox3.Location = new System.Drawing.Point(6, 25);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 0;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(10, 25);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(100, 24);
            this.comboBox2.TabIndex = 1;
            // 
            // AddCarPreferenceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 294);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSubmit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddCarPreferenceForm";
            this.Text = "AddCarForm";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            String vendor = comboBox1.Text;
            String model = textBox1.Text;
           
            int year = int.Parse(textBox2.Text);
            String color = comboBox2.Text;
            String transmission = textBox4.Text;
            String engine = textBox3.Text;

            

            CarSpecs carSpecs = new CarSpecs(engine,transmission,color,year);


            CarPreference carPreference = new CarPreference(vendor, model, carSpecs);
            client.addPreference(carPreference);


            
            
            
            
            //client.addPreference(carspecs)


          

         
            parentForm.LoadData();
            this.Close();
        }

    
    }

}
