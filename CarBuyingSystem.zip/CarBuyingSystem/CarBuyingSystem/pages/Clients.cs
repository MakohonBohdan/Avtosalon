﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarBuyingSystem
{
    public partial class Clients : Form
    {
        private Controller carController;

        public Clients(Controller carController)
        {
            this.carController = carController;
            InitializeComponent();
            carController.loadClients();
            LoadData();

            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Clients_FormClosing);
        }


        public void LoadData()
        {

            flowLayoutPanel1.Controls.Clear();

            List<Client> list = carController.GetClients();
       


            foreach (var client in list)
            {
                var clientControl = new CustomerControl( carController, this);
                clientControl.SetClient(client);
                flowLayoutPanel1.Controls.Add(clientControl);
            }

        }

        private void addCarForm_Click(object sender, EventArgs e)
        {
            AddClientForm form = new AddClientForm(carController, this);
            form.Show();
        }

        private void Clients_FormClosing(object sender, EventArgs e)
        {
            carController.saveClients();
        }
    }
}
