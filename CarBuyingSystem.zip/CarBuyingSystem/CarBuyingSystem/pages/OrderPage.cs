﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarBuyingSystem
{
    public partial class OrderPage : Form
    {
        private Order order; 
        private Controller controller;
        public OrderPage(Order order,Controller controller)
        {
            InitializeComponent();
            this.order = order;
            this.controller = controller;
            LoadData();
            
        }
        public void LoadData()
        {
            orderNumberField.Text = order.number.ToString();
            orderNameField.Text = order.Client.Name;
            orderPhoneField.Text = order.Client.Phone;
            orderEmailField.Text = order.Client.Email;
            createdField.Text = order.created.ToString();
            orderStatusField.Text = order.orderStatus.ToString();
           
            flowLayoutPanel1.Controls.Clear();
            List<Car> list = order.suggestedCars;

            foreach (Car car in list)
            {
                var someCar = new CarPrefControl();
                someCar.SetCar(car);
                flowLayoutPanel1.Controls.Add(someCar);
               
                
            }
            if (list.Count == 0)
            {
                foreach (CarPreference car in order.Client.CarPreferences)
                {
                    var someCar = new CarPrefControl();
                    someCar.SetCarPreference(car);
                    flowLayoutPanel2.Controls.Add(someCar);


                }
            }

        }
        private void AutoHata_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
