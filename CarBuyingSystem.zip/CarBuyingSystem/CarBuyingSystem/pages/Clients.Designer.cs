﻿namespace CarBuyingSystem
{
    partial class Clients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.p = new System.Windows.Forms.Panel();
            this.AutoHata = new System.Windows.Forms.Label();
            this.addCarForm = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.p.SuspendLayout();
            this.SuspendLayout();
            // 
            // p
            // 
            this.p.BackColor = System.Drawing.Color.DodgerBlue;
            this.p.Controls.Add(this.AutoHata);
            this.p.Controls.Add(this.addCarForm);
            this.p.Location = new System.Drawing.Point(0, 0);
            this.p.Name = "p";
            this.p.Size = new System.Drawing.Size(1295, 100);
            this.p.TabIndex = 4;
            // 
            // AutoHata
            // 
            this.AutoHata.AutoSize = true;
            this.AutoHata.BackColor = System.Drawing.Color.DodgerBlue;
            this.AutoHata.Font = new System.Drawing.Font("Arial", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AutoHata.ForeColor = System.Drawing.Color.Linen;
            this.AutoHata.Location = new System.Drawing.Point(545, 13);
            this.AutoHata.Name = "AutoHata";
            this.AutoHata.Size = new System.Drawing.Size(228, 74);
            this.AutoHata.TabIndex = 2;
            this.AutoHata.Text = "Clients";
            // 
            // addCarForm
            // 
            this.addCarForm.BackColor = System.Drawing.Color.RoyalBlue;
            this.addCarForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addCarForm.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addCarForm.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addCarForm.Location = new System.Drawing.Point(1130, 30);
            this.addCarForm.Name = "addCarForm";
            this.addCarForm.Size = new System.Drawing.Size(125, 40);
            this.addCarForm.TabIndex = 1;
            this.addCarForm.Text = "ADD";
            this.addCarForm.UseVisualStyleBackColor = false;
            this.addCarForm.Click += new System.EventHandler(this.addCarForm_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(60, 106);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1165, 600);
            this.flowLayoutPanel1.TabIndex = 5;
            // 
            // Clients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 711);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.p);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Clients";
            this.Text = "Clients";
            this.p.ResumeLayout(false);
            this.p.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel p;
        private System.Windows.Forms.Label AutoHata;
        private System.Windows.Forms.Button addCarForm;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
    }
}