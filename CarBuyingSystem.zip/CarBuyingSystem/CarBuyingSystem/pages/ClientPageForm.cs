﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarBuyingSystem
{
    public partial class ClientPageForm : Form
    {
       
        private Client client;

        private Controller controller;
        public ClientPageForm(Client client, Controller controller)
        {
            InitializeComponent();
         
            this.client = client;
            this.controller = controller;
            LoadData();
        }
        public void LoadData() {
            ClientNameField.Text = client.Name;
            ClientPhoneField.Text = client.Phone;
            ClientEmailField.Text = client.Email;
            costFromFilterField.Text = client.costFrom.ToString();
            costToFilterField.Text = client.costTo.ToString();
            ClientStatusField.Text = client.Status.ToString();

            flowLayoutPanel1.Controls.Clear();
            List<CarPreference> list = client.CarPreferences;


            foreach (CarPreference preference in list) {
                var carPreeference = new CarPrefControl();

                carPreeference.SetCarPreference(preference);
                flowLayoutPanel1 .Controls.Add(carPreeference);
            }

        }

        private void addCarForm_Click(object sender, EventArgs e)
        {
            AddCarPreferenceForm adFrom = new AddCarPreferenceForm(client, this);
            adFrom.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            controller.makeOrder(client);

        }
    }
}
