﻿using CarBuyingSystem;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CarBuyingSystem
{
    public partial class CarCRUDForm : Form
    {

        private DataGridView dgvCars;
        private Controller carController;
        private Button addCarForm;

        private GroupBox groupBox2;
        private Label label3;
        private Label label4;
        private GroupBox groupBox3;
        private GroupBox groupBox4;
        private ComboBox vendors;
        private GroupBox groupBox5;
        private TextBox modelFilter;
        private TextBox costToFilter;
        private TextBox costFromFilter;
        private TextBox runToFilter;
        private TextBox runFromFilter;
        private Label label5;
        private Label label6;
        private Label AutoHata;
        private Panel p;
        private GroupBox groupBox1;
        private Label label1;
        private NumericUpDown fromYear;
        private NumericUpDown toYear;
        private Label label2;
        private Button filterButton;
        private Button clearFilter;

        public CarCRUDForm(Controller carController)
        {
            InitializeComponent();
            InitializeDataGridView();
            this.carController = carController;
            LoadCars();
            LoadData();
        }

        private void InitializeComponent()
        {
            this.dgvCars = new System.Windows.Forms.DataGridView();
            this.addCarForm = new System.Windows.Forms.Button();
            this.AutoHata = new System.Windows.Forms.Label();
            this.p = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.toYear = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.fromYear = new System.Windows.Forms.NumericUpDown();
            this.filterButton = new System.Windows.Forms.Button();
            this.clearFilter = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.costToFilter = new System.Windows.Forms.TextBox();
            this.costFromFilter = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.runToFilter = new System.Windows.Forms.TextBox();
            this.runFromFilter = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.vendors = new System.Windows.Forms.ComboBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.modelFilter = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCars)).BeginInit();
            this.p.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.toYear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fromYear)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvCars
            // 
            this.dgvCars.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCars.Location = new System.Drawing.Point(21, 179);
            this.dgvCars.Name = "dgvCars";
            this.dgvCars.Size = new System.Drawing.Size(1268, 358);
            this.dgvCars.TabIndex = 0;
            // 
            // addCarForm
            // 
            this.addCarForm.BackColor = System.Drawing.Color.RoyalBlue;
            this.addCarForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addCarForm.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addCarForm.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addCarForm.Location = new System.Drawing.Point(1130, 30);
            this.addCarForm.Name = "addCarForm";
            this.addCarForm.Size = new System.Drawing.Size(125, 40);
            this.addCarForm.TabIndex = 1;
            this.addCarForm.Text = "ADD";
            this.addCarForm.UseVisualStyleBackColor = false;
            this.addCarForm.Click += new System.EventHandler(this.addCarForm_Click);
            // 
            // AutoHata
            // 
            this.AutoHata.AutoSize = true;
            this.AutoHata.BackColor = System.Drawing.Color.DodgerBlue;
            this.AutoHata.Font = new System.Drawing.Font("Arial", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AutoHata.ForeColor = System.Drawing.Color.Linen;
            this.AutoHata.Location = new System.Drawing.Point(545, 13);
            this.AutoHata.Name = "AutoHata";
            this.AutoHata.Size = new System.Drawing.Size(301, 74);
            this.AutoHata.TabIndex = 2;
            this.AutoHata.Text = "AutoHata";
            // 
            // p
            // 
            this.p.BackColor = System.Drawing.Color.DodgerBlue;
            this.p.Controls.Add(this.AutoHata);
            this.p.Controls.Add(this.addCarForm);
            this.p.Location = new System.Drawing.Point(0, 0);
            this.p.Name = "p";
            this.p.Size = new System.Drawing.Size(1300, 100);
            this.p.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.toYear);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.fromYear);
            this.groupBox1.Location = new System.Drawing.Point(263, 110);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 54);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Year Filter";
            // 
            // toYear
            // 
            this.toYear.Location = new System.Drawing.Point(122, 24);
            this.toYear.Maximum = new decimal(new int[] {
            2023,
            0,
            0,
            0});
            this.toYear.Name = "toYear";
            this.toYear.Size = new System.Drawing.Size(48, 20);
            this.toYear.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(96, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "To";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "From";
            // 
            // fromYear
            // 
            this.fromYear.Location = new System.Drawing.Point(42, 24);
            this.fromYear.Maximum = new decimal(new int[] {
            2023,
            0,
            0,
            0});
            this.fromYear.Name = "fromYear";
            this.fromYear.Size = new System.Drawing.Size(48, 20);
            this.fromYear.TabIndex = 0;
            // 
            // filterButton
            // 
            this.filterButton.BackColor = System.Drawing.Color.RoyalBlue;
            this.filterButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.filterButton.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.filterButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.filterButton.Location = new System.Drawing.Point(999, 118);
            this.filterButton.Name = "filterButton";
            this.filterButton.Size = new System.Drawing.Size(125, 40);
            this.filterButton.TabIndex = 3;
            this.filterButton.Text = "Search";
            this.filterButton.UseVisualStyleBackColor = false;
            this.filterButton.Click += new System.EventHandler(this.filterButton_Click);
            // 
            // clearFilter
            // 
            this.clearFilter.BackColor = System.Drawing.Color.RoyalBlue;
            this.clearFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clearFilter.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.clearFilter.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.clearFilter.Location = new System.Drawing.Point(1130, 118);
            this.clearFilter.Name = "clearFilter";
            this.clearFilter.Size = new System.Drawing.Size(125, 40);
            this.clearFilter.TabIndex = 5;
            this.clearFilter.Text = "Clear";
            this.clearFilter.UseVisualStyleBackColor = false;
            this.clearFilter.Click += new System.EventHandler(this.clearFilter_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.costToFilter);
            this.groupBox2.Controls.Add(this.costFromFilter);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(467, 110);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 54);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cost Filter";
            // 
            // costToFilter
            // 
            this.costToFilter.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.costToFilter.Location = new System.Drawing.Point(122, 21);
            this.costToFilter.Name = "costToFilter";
            this.costToFilter.Size = new System.Drawing.Size(48, 22);
            this.costToFilter.TabIndex = 3;
            this.costToFilter.Text = "0";
            // 
            // costFromFilter
            // 
            this.costFromFilter.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.costFromFilter.Location = new System.Drawing.Point(42, 21);
            this.costFromFilter.Name = "costFromFilter";
            this.costFromFilter.Size = new System.Drawing.Size(48, 22);
            this.costFromFilter.TabIndex = 2;
            this.costFromFilter.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(96, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "To";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "From";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.runToFilter);
            this.groupBox3.Controls.Add(this.runFromFilter);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(672, 110);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 54);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Run Distanse Filter";
            // 
            // runToFilter
            // 
            this.runToFilter.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.runToFilter.Location = new System.Drawing.Point(131, 21);
            this.runToFilter.Name = "runToFilter";
            this.runToFilter.Size = new System.Drawing.Size(48, 22);
            this.runToFilter.TabIndex = 7;
            this.runToFilter.Text = "0";
            // 
            // runFromFilter
            // 
            this.runFromFilter.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.runFromFilter.Location = new System.Drawing.Point(51, 21);
            this.runFromFilter.Name = "runFromFilter";
            this.runFromFilter.Size = new System.Drawing.Size(48, 22);
            this.runFromFilter.TabIndex = 5;
            this.runFromFilter.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(105, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(20, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "To";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "From";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.vendors);
            this.groupBox4.Location = new System.Drawing.Point(21, 110);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(116, 54);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Vendor Filter";
            // 
            // vendors
            // 
            this.vendors.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.vendors.FormattingEnabled = true;
            this.vendors.Location = new System.Drawing.Point(6, 19);
            this.vendors.Name = "vendors";
            this.vendors.Size = new System.Drawing.Size(100, 24);
            this.vendors.TabIndex = 1;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.modelFilter);
            this.groupBox5.Location = new System.Drawing.Point(143, 110);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(116, 54);
            this.groupBox5.TabIndex = 10;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Model Filter";
            // 
            // modelFilter
            // 
            this.modelFilter.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.modelFilter.Location = new System.Drawing.Point(8, 19);
            this.modelFilter.Name = "modelFilter";
            this.modelFilter.Size = new System.Drawing.Size(100, 22);
            this.modelFilter.TabIndex = 1;
            // 
            // CarCRUDForm
            // 
            this.ClientSize = new System.Drawing.Size(1284, 707);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.clearFilter);
            this.Controls.Add(this.filterButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.p);
            this.Controls.Add(this.dgvCars);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CarCRUDForm";
            this.Text = "Cars";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CarCRUDForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCars)).EndInit();
            this.p.ResumeLayout(false);
            this.p.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.toYear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fromYear)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        private void InitializeDataGridView()
        {
            // Add columns
            dgvCars.ColumnCount = 12;
            dgvCars.Columns[0].Name = "Vendor";
            dgvCars.Columns[1].Name = "Model";
            dgvCars.Columns[2].Name = "Year";
            dgvCars.Columns[3].Name = "Cost";
            dgvCars.Columns[4].Name = "Engine Volume";
            dgvCars.Columns[5].Name = "Gears";
            dgvCars.Columns[6].Name = "Fuel Type";
            dgvCars.Columns[7].Name = "Consumption";
            dgvCars.Columns[8].Name = "Body Type";
            dgvCars.Columns[9].Name = "Color";
            dgvCars.Columns[10].Name = "State";
            dgvCars.Columns[11].Name = "Run Distance";
        }

        public void LoadCars()
        {
            dgvCars.Rows.Clear();


            foreach (var car in carController.GetCars())
            {
                string[] row = new string[] {car.VendorName, car.Model, car.Year.ToString(),car.Cost.ToString(),
                car.Engine.EngineVolume.ToString(), car.GearBox.ToString(), car.Engine.FuelType.ToString(), car.Engine.Consumption.ToString(),
                car.BodyType.ToString(), car.Color.ToString(), car.State, car.RunDistance.ToString() };
                dgvCars.Rows.Add(row);
            }
        }


        private void LoadData()
        {
            List<string> carVendors = new List<string>()
            {
            "","AC","Alpine","Audi","Acura","Aro","Austin","Alfa Romeo","Asia","Alpina","Aston Martin","BAW","Brilliance","BYD","Beijing","Bristol","Богдан","Bentley","Bugatti","BMW","Buick","Vector","Vortex",
            "Wuling","Venturi","Wartburg","ВАЗ (Lada)","Volkswagen","Westfield","Volvo","Wiesmann","Geely","ГАЗ","Geo","GMC","Great Wall","Dacia","Daimler","Dodge","Jiangling","Dadi","Dallas","Dong Feng","Jiangnan",
            "Daewoo","Derways","Doninvest","Daihatsu","De Tomaso","Jeep","Eagle","Zastava","ZX","ЗАЗ","ЗИЛ","Infiniti","Isdera","ИЖ","Innocenti","Isuzu","Invicta","IVECO","Iran Khodro","Xin Kai","Cadillac","Citroen",
            "Koenigsegg","Callaway","Cizeta","Qvale","Carbodies","Coggiola","КАМАЗ","Caterham","Kia","Lamborghini","Lexus","LTI","Lancia","Lifan","Luxgen","Land Rover","Lincoln","ЛуАЗ","Landwind","Lotus","Mahindra",
            "Maruti","McLaren","Metrocab","Mitsubishi","Москвич","Marcos","Maserati","Mega","MG","Mitsuoka","Marlin","Maybach","Mercedes-Benz","Minelli","Monte Carlo","Marussia","Mazda","Mercury","Mini","Morgan","Nissan",
            "Noble","Oldsmobile","Opel","Pagani","Peugeot","Premier","Panoz","Plymouth","Proton","Paykan","Pontiac","Puma","Perodua","Porsche","Reliant","Rover","Renault","Ravon","Rolls-Royce","Ronart","Saab","Scion",
            "Smart","Subaru","Saleen","SEAT","Soueast","Suzuki","Samsung","Skoda","Spectre","СеАЗ","Saturn","SMA","SsangYong","Talbot","Tofas","ТагАЗ","Tata","Toyota","Tatra","Trabant","Tianma","TVR","УАЗ","FAW","FSO",
            "Ferrari","Fuqi","Fiat","Ford","Hafei","Honda","Haval","Haima","HuangHai","Hindustan","Hummer","Holden","Hyundai","Chana","Chevrolet","ChangFeng","Chrysler","Changhe","Chery","Shifeng","ShuangHuan","JAC","Jaguar"
            };

            vendors.DataSource = carVendors;
        }



        private void addCarForm_Click(object sender, EventArgs e)
        {

            AddCarForm addCarForm = new AddCarForm(this.carController, this);
            addCarForm.Show();

        }

        private void filterButton_Click(object sender, EventArgs e)
        {

            string selectedVendor = vendors.Text;
            string selectedModel = modelFilter.Text;


            int yearFrom = 0;
            int.TryParse(fromYear.Text, out yearFrom);
            int yearTo = 0;
            int.TryParse(toYear.Text, out yearTo);

            int costFrom = 0;
            int.TryParse(costFromFilter.Text, out costFrom);


            int costTo =0;
            int.TryParse(costToFilter.Text, out costTo);

            int runFrom =0;
            int.TryParse(runFromFilter.Text, out runFrom);

            int runTo = 0;

            int.TryParse(runToFilter.Text, out runTo);

            dgvCars.Rows.Clear();


            foreach (var car in carController.GetCarsBy(selectedVendor, selectedModel,yearFrom, yearTo, costFrom, costTo, runFrom, runTo))
            {
                string[] row = new string[] { car.VendorName, car.Model, car.Year.ToString(), car.Cost.ToString(),
                car.Engine.EngineVolume.ToString(), car.GearBox.ToString(), car.Engine.FuelType.ToString(), car.Engine.Consumption.ToString(),
                car.BodyType.ToString(), car.Color.ToString(), car.State, car.RunDistance.ToString() };
                dgvCars.Rows.Add(row);
            }


        }

      

        private void clearFilter_Click(object sender, EventArgs e)
        {
            LoadCars();

        }

        private void CarCRUDForm_FormClosing(object sender, EventArgs e)
        {
            carController.saveCars();
        }
    }
}
