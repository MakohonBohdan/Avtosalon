﻿namespace CarBuyingSystem
{
    partial class ClientPageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.addCarForm = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ClientStatusField = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.costToFilterField = new System.Windows.Forms.TextBox();
            this.costFromFilterField = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ClientEmailField = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ClientPhoneField = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ClientNameField = new System.Windows.Forms.TextBox();
            this.AutoHata = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.addCarForm);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.AutoHata);
            this.panel1.Location = new System.Drawing.Point(-8, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1197, 178);
            this.panel1.TabIndex = 27;
            // 
            // addCarForm
            // 
            this.addCarForm.BackColor = System.Drawing.Color.RoyalBlue;
            this.addCarForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addCarForm.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addCarForm.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addCarForm.Location = new System.Drawing.Point(1052, 77);
            this.addCarForm.Name = "addCarForm";
            this.addCarForm.Size = new System.Drawing.Size(125, 40);
            this.addCarForm.TabIndex = 33;
            this.addCarForm.Text = "ADD";
            this.addCarForm.UseVisualStyleBackColor = false;
            this.addCarForm.Click += new System.EventHandler(this.addCarForm_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ClientStatusField);
            this.groupBox5.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox5.Location = new System.Drawing.Point(857, 83);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(176, 60);
            this.groupBox5.TabIndex = 28;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Client Status";
            // 
            // ClientStatusField
            // 
            this.ClientStatusField.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ClientStatusField.FormattingEnabled = true;
            this.ClientStatusField.Location = new System.Drawing.Point(8, 24);
            this.ClientStatusField.Name = "ClientStatusField";
            this.ClientStatusField.Size = new System.Drawing.Size(155, 24);
            this.ClientStatusField.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.costToFilterField);
            this.groupBox4.Controls.Add(this.costFromFilterField);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox4.Location = new System.Drawing.Point(618, 83);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(240, 60);
            this.groupBox4.TabIndex = 32;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Client Budget";
            // 
            // costToFilterField
            // 
            this.costToFilterField.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.costToFilterField.Location = new System.Drawing.Point(163, 25);
            this.costToFilterField.Name = "costToFilterField";
            this.costToFilterField.Size = new System.Drawing.Size(50, 22);
            this.costToFilterField.TabIndex = 3;
            this.costToFilterField.Text = "100000";
            // 
            // costFromFilterField
            // 
            this.costFromFilterField.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.costFromFilterField.Location = new System.Drawing.Point(70, 25);
            this.costFromFilterField.Name = "costFromFilterField";
            this.costFromFilterField.Size = new System.Drawing.Size(50, 22);
            this.costFromFilterField.TabIndex = 2;
            this.costFromFilterField.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(131, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "To";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "From";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ClientEmailField);
            this.groupBox3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.Location = new System.Drawing.Point(419, 83);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 60);
            this.groupBox3.TabIndex = 29;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Client Email";
            // 
            // ClientEmailField
            // 
            this.ClientEmailField.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ClientEmailField.Location = new System.Drawing.Point(6, 25);
            this.ClientEmailField.Name = "ClientEmailField";
            this.ClientEmailField.Size = new System.Drawing.Size(155, 22);
            this.ClientEmailField.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ClientPhoneField);
            this.groupBox1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(221, 83);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 60);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Client Phone";
            // 
            // ClientPhoneField
            // 
            this.ClientPhoneField.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ClientPhoneField.Location = new System.Drawing.Point(6, 25);
            this.ClientPhoneField.Name = "ClientPhoneField";
            this.ClientPhoneField.Size = new System.Drawing.Size(155, 22);
            this.ClientPhoneField.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ClientNameField);
            this.groupBox2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.Location = new System.Drawing.Point(22, 83);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 60);
            this.groupBox2.TabIndex = 28;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Client Name";
            // 
            // ClientNameField
            // 
            this.ClientNameField.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ClientNameField.Location = new System.Drawing.Point(6, 25);
            this.ClientNameField.Name = "ClientNameField";
            this.ClientNameField.Size = new System.Drawing.Size(155, 22);
            this.ClientNameField.TabIndex = 0;
            // 
            // AutoHata
            // 
            this.AutoHata.AutoSize = true;
            this.AutoHata.BackColor = System.Drawing.Color.DodgerBlue;
            this.AutoHata.Font = new System.Drawing.Font("Arial", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AutoHata.ForeColor = System.Drawing.Color.Linen;
            this.AutoHata.Location = new System.Drawing.Point(446, 3);
            this.AutoHata.Name = "AutoHata";
            this.AutoHata.Size = new System.Drawing.Size(365, 74);
            this.AutoHata.TabIndex = 28;
            this.AutoHata.Text = "Client Page";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(19, 185);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1150, 574);
            this.flowLayoutPanel1.TabIndex = 28;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.RoyalBlue;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(1052, 123);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 40);
            this.button1.TabIndex = 34;
            this.button1.Text = "Order";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ClientPageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1188, 772);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ClientPageForm";
            this.Text = "ClientPageForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label AutoHata;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox ClientEmailField;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox ClientPhoneField;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox ClientNameField;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox costToFilterField;
        private System.Windows.Forms.TextBox costFromFilterField;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ComboBox ClientStatusField;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button addCarForm;
        private System.Windows.Forms.Button button1;
    }
}