﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarBuyingSystem
{
    internal static class Program
    {
       
        [STAThread]
        static void Main()
        {
            Controller controller = new Controller();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainPage(controller));
        }
    }
}
