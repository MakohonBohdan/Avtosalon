﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace CarBuyingSystem
{
    public partial class GearBox
    {

        public int GearsAmount { get; set; }
        public GearBoxType type { get; set; }

        public string Name { get; set; }

        public GearBox(int gearsAmount, GearBoxType type, string name)
        {
            GearsAmount = gearsAmount;
            this.type = type;
            Name = name;
        }

        public override string ToString()
        {
            return GearsAmount + " " + type + " " + Name;

        }

    }

    public enum GearBoxType { Manual, Robotics, Variator}
}
