﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBuyingSystem
{
    public partial class Engine
    {

        public double EngineVolume { get; set; }
        public string FuelType { get; set; }

        public double Consumption { get; set; }


        public Engine() { }

        public Engine(double engineVolume, string fuelType, double consumption)
        {
            EngineVolume = engineVolume;
            FuelType = fuelType;
            Consumption = consumption;
        }

        public override string ToString()
        {
            return EngineVolume+" "+FuelType+" "+Consumption;
        }
    }
}
