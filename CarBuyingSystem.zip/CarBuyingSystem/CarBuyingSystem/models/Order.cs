﻿using System;
using System.Collections.Generic;


namespace CarBuyingSystem
{
    public partial class Order
    {
        public int number { get; set; }
        public Client Client { get; set; }
        public List<Car> suggestedCars { get; set; }

        public OrderStatus orderStatus { get; set; }

        public Car Car { get; set; }
        public DateTime created { get; set; }

        public DateTime updated { get; set; }

        public DateTime delivered { get; set; }

        public void addCar(Car car)
        {
            suggestedCars.Add(car);
        }


    }
    public enum OrderStatus { NEW, IN_PROGRESS, DELAYED, CANCELED, DONE }





}



