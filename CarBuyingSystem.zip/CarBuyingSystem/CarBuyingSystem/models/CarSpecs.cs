﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBuyingSystem
{
    public class CarSpecs
    {
        public string EngineType { get; set; }
        public string Transmission { get; set; }
        public string Color { get; set; }
        public int Year { get; set; }

        public CarSpecs(string engineType, string transmission, string color, int year)
        {
            EngineType = engineType;
            Transmission = transmission;
            Color = color;
            Year = year;
        }   
    }
}
