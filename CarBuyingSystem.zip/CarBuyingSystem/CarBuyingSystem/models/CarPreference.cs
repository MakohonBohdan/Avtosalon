﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBuyingSystem
{
    public class CarPreference
    {
        public String PreferredVendor { get; set; }
        public String PreferredModel { get; set; }
        public CarSpecs PreferredSpecs { get; set; }


        public CarPreference(string preferredVendor, string preferredModel, CarSpecs preferredSpecs)
        {
            PreferredVendor = preferredVendor;
            PreferredModel = preferredModel;
            PreferredSpecs = preferredSpecs;
        }
    }
}
