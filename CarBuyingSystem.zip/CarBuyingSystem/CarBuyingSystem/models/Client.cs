﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace CarBuyingSystem
{
    public class Client
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int costFrom { get; set; }
        public int costTo { get; set; }

        public ClientStatus Status { get; set; }

        public List<CarPreference> CarPreferences { get; set; }

        public Client()
        {
            CarPreferences = new List<CarPreference>();
        }

        public Client(string name, string email, string phone, ClientStatus clientStatus, int costFrom , int costTo)
        {
            Name = name;
            Email = email;
            Phone = phone;
            this.costFrom = costFrom;
            this.costTo = costTo;
            this.Status = clientStatus;
            CarPreferences = new List<CarPreference>();
        }
        public void addPreference(CarPreference carpreference)
        {
            CarPreferences.Add(carpreference);
        } 
    }

    public enum ClientStatus { NEW, CURRENT, CLOSED}
}
