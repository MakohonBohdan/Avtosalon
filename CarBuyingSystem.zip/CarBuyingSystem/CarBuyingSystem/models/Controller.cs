﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.IO;

namespace CarBuyingSystem
{
    public partial class Controller
    {

        private List<Car> cars;
        private List<Client> clients;
        private List<Order> orders;


        public Controller()
        {
            cars = new List<Car>();
            clients = new List<Client>();

            orders = new List<Order>();

            loadCars();
            loadClients();
            loadOrders();

        }

        ~Controller()
        {
            saveCars();
            saveClients();
            saveOrders();

        }


        public void addCar(Car car)
        {
            cars.Add(car);
        }

        public void addClient(Client client)
        {
            clients.Add(client);
        }

        public List<Car> GetCars()
        {
            return cars;
        }

        public List<Client> GetClients()
        {

            return clients;
        }

        public List<Car> GetCarsBy(string vendor, string model, int fromYear, int toYear, int costFrom, int costTo, int runFrom, int runTo)
        {
            List<Car> result = new List<Car>(cars);



            if (!string.IsNullOrEmpty(vendor))
            {
                result = result.Where(car => car.VendorName.Equals(vendor)).ToList();

            }


            if (fromYear != 0 && toYear != 0 && fromYear <= toYear)
            {
                result = result.Where(car => car.Year >= fromYear && car.Year <= toYear).ToList();


            }

            if (costFrom != 0 && costTo != 0)
            {
                result = result.Where(car => car.Cost >= costFrom && car.Cost <= costTo).ToList();


            }

            if (runFrom != 0 && runTo != 0)
            {
                result = result.Where(car => car.RunDistance >= runFrom && car.RunDistance <= runTo).ToList();


            }


            return result;
        }


        public void deleteClient(Client client)
        {
            clients.Remove(client);
        }
        public List<Order> getOrders()
        {

            return this.orders;

        }

        public void deleteOrder(Order order)
        {
            orders.Remove(order);

        }
        public void makeOrder(Client client)
        {
            List<Car> result = new List<Car>(cars);

            List<Car> finalResult = new List<Car>();


            int costFrom = client.costFrom;
            int costTo = client.costTo;

            if (costFrom != 0 && costTo != 0)
            {
                result = result.Where(car => car.Cost >= costFrom && car.Cost <= costTo).ToList();

            }

            List<CarPreference> carPreferences = client.CarPreferences;

            foreach (var preference in carPreferences)
            {
                var tempResult = result
                    .Where(car =>
                        car.VendorName == preference.PreferredVendor &&
                        car.Model == preference.PreferredModel &&
                        car.Year >= preference.PreferredSpecs.Year
                        )

                    .ToList();


                finalResult.AddRange(tempResult);
            }
            finalResult = finalResult.Distinct().ToList();

            Order current = new Order();

            Random rnd = new Random();

            current.number = rnd.Next(1000, 10000);
            current.suggestedCars = finalResult;
            current.Client = client;
            current.created = DateTime.Now;
            current.updated = DateTime.Now;


            orders.Add(current);


        }


        public void loadCars()
        {

            string jsonString = File.ReadAllText("C:\\Users\\Богдан\\source\\repos\\CarBuyingSystem\\CarBuyingSystem\\data\\cars.json");
            cars = JsonSerializer.Deserialize<List<Car>>(jsonString);

        }

        public void saveCars()
        {
            string jsonString = JsonSerializer.Serialize(cars);
            File.WriteAllText("C:\\Users\\Богдан\\source\\repos\\CarBuyingSystem\\CarBuyingSystem\\data\\cars.json", jsonString);

        }


        public void loadClients()
        {

            string jsonString = File.ReadAllText("C:\\Users\\Богдан\\source\\repos\\CarBuyingSystem\\CarBuyingSystem\\data\\clients.json");
            clients = JsonSerializer.Deserialize<List<Client>>(jsonString);

        }
        public void saveClients()
        {
            string jsonString = JsonSerializer.Serialize(clients);
            File.WriteAllText("C:\\Users\\Богдан\\source\\repos\\CarBuyingSystem\\CarBuyingSystem\\data\\clients.json", jsonString);

        }
        public void loadOrders()
        {

            string jsonString = File.ReadAllText("C:\\Users\\Богдан\\source\\repos\\CarBuyingSystem\\CarBuyingSystem\\data\\orders.json");
            orders = JsonSerializer.Deserialize<List<Order>>(jsonString);

        }
        public void saveOrders()
        {
            string jsonString = JsonSerializer.Serialize(orders);
            File.WriteAllText("C:\\Users\\Богдан\\source\\repos\\CarBuyingSystem\\CarBuyingSystem\\data\\orders.json", jsonString);
        }
    }
}
