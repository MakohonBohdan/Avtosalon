﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarBuyingSystem
{
    public partial class Car
    {
        public string VendorName { get; set; }
        public string Model { get; set; }

        public int Year { get; set; }

        public double Cost { get; set; }

        public Engine Engine { get; set; }

        public GearBox GearBox { get; set; }

        public BodyType BodyType { get; set; }

        public Color Color { get; set; }

        public string State { get; set; }

        public double RunDistance { get; set; }

        public Car(string vendorName, string model, int year, double cost, 
            Engine engine, GearBox gearBox, BodyType bodyType, 
            Color color, string state, double runDistance)
        {
            VendorName = vendorName;
            Model = model;
            Year = year;
            Cost = cost;
            Engine = engine;
            GearBox = gearBox;
            BodyType = bodyType;
            Color = color;
            State = state;
            RunDistance = runDistance;
        }
    }

    public enum BodyType { Sedan , StationWagon , Cabriolet , Offroad, Hatchback , Coupe , Crossover , Pickup , Van , Minivan }

    public enum Color {Black, White , Red , Yellow , Orange , Green , Blue , Purple , Pink , Brown , Gray }

}
