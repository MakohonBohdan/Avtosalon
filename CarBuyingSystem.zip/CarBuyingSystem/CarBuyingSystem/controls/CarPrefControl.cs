﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarBuyingSystem
{
    public partial class CarPrefControl : UserControl
    {
        public CarPreference carPreference { get; set; }
        public CarPrefControl()
        {
            InitializeComponent();
        }

        public void SetCarPreference(CarPreference carPreference)
        {
            this.carPreference = carPreference;
            CarVendorField.Text = carPreference.PreferredVendor;
            CarModelField.Text = carPreference.PreferredModel;
            EngineTypeField.Text = carPreference.PreferredSpecs.EngineType;
            TransmissionField.Text = carPreference.PreferredSpecs.Transmission;
         
            ColorField.Text = carPreference.PreferredSpecs.Color;
            YearField.Text = carPreference.PreferredSpecs.Year.ToString();

        }
        public void SetCar(Car car)
        {
            CarVendorField.Text = car.VendorName;
            CarModelField.Text = car.Model;
            EngineTypeField.Text = car.Engine.EngineVolume.ToString();
            TransmissionField.Text = car.GearBox.Name;
            ColorField.Text = car.Color.ToString();
            YearField.Text = car.Year.ToString();



        }
    }
}
   

