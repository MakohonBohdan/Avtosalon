﻿using CarBuyingSystem.pages;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarBuyingSystem.controls
{
    public partial class OrderControl : UserControl
    {
        public Order order { get; set; }
        public Orders orders { get; set; }

        public Controller controller { get; set; }



        public OrderControl(Controller controller, Orders parent)
        {
            InitializeComponent();
            this.controller = controller;
            this.orders = parent;
        }
        public void SetOrder(Order order)
        {
            this.order = order;
            orderNumberField.Text = order.number.ToString();
            clientNameField.Text = order.Client.Name;
            clientPhoneField.Text = order.Client.Phone;
            orderStatusField.Text = order.orderStatus.ToString();
            orderCreatedField.Text = order.created.ToString();
            orderDeliveredField.Text = order.delivered.ToString();

        }

        private void openButton_Click(object sender, EventArgs e)
        {
            OrderPage page = new OrderPage(this.order, controller);
            page.Show();    
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            controller.deleteOrder(order);
            orders.LoadData();

        }
    }
}
