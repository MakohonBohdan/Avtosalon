﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarBuyingSystem
{
    public partial class CustomerControl : UserControl
    {
        public Client client { get; set; }
        public Clients parent { get; set; }

        public Controller controller { get; set; }
        public CustomerControl(Controller controller, Clients parent)
        {
            InitializeComponent();
            this.controller = controller;
            this.parent = parent;
        }

        public void SetClient(Client client)
        {
            this.client = client;
            clientNameField.Text = client.Name;
            clientPhoneField.Text = client.Phone;
            clientEmailField.Text = client.Email;
            clientStatusField.Text = client.Status.ToString();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            ClientPageForm clientPageForm = new ClientPageForm(client , controller);
            clientPageForm.Show();

        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
           
            controller.deleteClient(client);
            parent.LoadData();

        }
    }
}
